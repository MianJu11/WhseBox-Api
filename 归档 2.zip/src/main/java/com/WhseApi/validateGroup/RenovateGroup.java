package com.WhseApi.validateGroup;

public interface RenovateGroup {
}
