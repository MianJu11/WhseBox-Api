package com.WhseApi.validateGroup;

public interface UpdateGroup {
}
