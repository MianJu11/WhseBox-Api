package com.WhseApi.validateGroup;

public interface BuyRenovateGroup {
}
