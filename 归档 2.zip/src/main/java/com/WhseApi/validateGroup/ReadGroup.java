package com.WhseApi.validateGroup;

public interface ReadGroup {
}
