package com.WhseApi.validateGroup;

public interface AddGroup {
}
