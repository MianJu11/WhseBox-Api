package com.WhseApi.validateGroup;

public interface BuyStickGroup {
}
